package at.aau.itec.emmt.jpeg.stud;

import at.aau.itec.emmt.jpeg.impl.AbstractHuffmanCoder;
import at.aau.itec.emmt.jpeg.spec.BlockI;
import at.aau.itec.emmt.jpeg.spec.RunLevelI;

public class HuffmanCoder extends AbstractHuffmanCoder {

    @Override
    public RunLevelI[] runLengthEncode(BlockI quantBlock) {
        return new RunLevelI[0];
    }
}
