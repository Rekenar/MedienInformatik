package at.aau.itec.emmt.jpeg.stud;

import at.aau.itec.emmt.jpeg.spec.BlockI;
import at.aau.itec.emmt.jpeg.spec.DCTBlockI;
import at.aau.itec.emmt.jpeg.spec.DCTI;

public class StandardDCT implements DCTI {

    @Override
    public DCTBlockI forward(BlockI b) {
        return null;
    }

}
